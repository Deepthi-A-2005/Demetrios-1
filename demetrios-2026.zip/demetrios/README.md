# Demetrios — Agriculture Rover

A real-time IoT dashboard for the **Demetrios** smart agriculture rover. Monitor sensors, control movement, view crop health, and track field GPS — all from your phone as a native-like PWA.

## Features
- 📡 **Real-time sensor data** — soil moisture, temperature, humidity, soil pH, ultrasonic obstacle detection, battery
- 🎮 **Rover control** — manual & autonomous drive modes
- 📷 **Crop camera & AI analysis** — capture and classify crop health
- 🗺️ **GPS field map** — live rover position overlay
- 🔔 **Smart alerts** — threshold-based notifications
- 📲 **Install as mobile app** — full PWA with home screen icon

## Install as Mobile App (PWA)

### Android (Chrome)
1. Open the app URL in Chrome
2. Tap the **⋮ menu** → **"Add to Home screen"**
3. Tap **Add** — the app appears as **Demetrios** with the rover icon

### iOS (Safari)
1. Open the app URL in Safari
2. Tap the **Share button** (box with arrow)
3. Scroll and tap **"Add to Home Screen"**
4. The name shows as **Demetrios** — tap **Add**

## Development Setup

### Prerequisites
- Node.js 18+ or Bun
- Supabase project (for live data storage)

### Install & Run
```bash
npm install
# copy .env.example to .env and fill in your Supabase URL & anon key
npm run dev
```

### Environment Variables
```
VITE_SUPABASE_URL=https://your-project.supabase.co
VITE_SUPABASE_ANON_KEY=your-anon-key
```

### Build for Production
```bash
npm run build
# Output in dist/ — deploy to any static host (Netlify, Vercel, Cloudflare Pages)
```

## Real-Time Data Architecture

The app uses **Supabase Realtime** for live sensor updates:
- `sensor_readings` table — streamed live every 2 seconds from rover
- `rover_state` table — current command, mode, online status
- `alerts` table — threshold breach notifications
- `crop_analyses` table — camera capture results

In **demo mode** (no Supabase), the built-in simulator (`agriSimulator.ts`) generates realistic sensor data so the dashboard works offline.

## Tech Stack
- React 19 + TanStack Router/Start
- Tailwind CSS v4
- Supabase (PostgreSQL + Realtime)
- Recharts for live graphs
- Vite + TypeScript
- PWA (Web App Manifest + Service Worker ready)
