import { createFileRoute } from "@tanstack/react-router";
import {
  ArrowUp, ArrowDown, ArrowLeft, ArrowRight, Square, Droplets,
  Tractor, Sprout, Gauge, Power, Zap,
} from "lucide-react";
import { useRover, useSensorHistory } from "@/hooks/useAgriData";
import { useState } from "react";

export const Route = createFileRoute("/control")({
  component: ControlPage,
});

function ControlPage() {
  const { state, update } = useRover();
  const { latest } = useSensorHistory(1);
  const [pressed, setPressed] = useState<string | null>(null);

  const move = (cmd: string) => {
    setPressed(cmd);
    update({ command: cmd });
    if (navigator.vibrate) navigator.vibrate(15);
    setTimeout(() => setPressed(null), 250);
  };

  const Btn = ({
    cmd, icon: Icon, variant = "default", className = "",
  }: { cmd: string; icon: typeof ArrowUp; variant?: "default" | "stop"; className?: string }) => {
    const active = state?.command === cmd || pressed === cmd;
    const stop = variant === "stop";
    return (
      <button
        onPointerDown={() => move(cmd)}
        className={`relative h-20 rounded-3xl flex items-center justify-center transition-all border active:scale-95 touch-manipulation ${
          stop
            ? active
              ? "bg-destructive text-destructive-foreground border-destructive shadow-[0_0_30px_oklch(0.65_0.24_25/0.5)]"
              : "bg-destructive/10 text-destructive border-destructive/30"
            : active
              ? "grad-primary text-primary-foreground border-transparent glow-primary"
              : "bg-card text-foreground border-border hover:bg-surface-elevated"
        } ${className}`}
      >
        <Icon size={28} strokeWidth={active ? 3 : 2.4} />
      </button>
    );
  };

  return (
    <div className="px-4 pt-6 safe-top">
      <header className="mb-5">
        <p className="text-xs font-medium uppercase tracking-widest text-muted-foreground">Manual override</p>
        <h1 className="mt-1 text-3xl font-bold tracking-tight">Rover Control</h1>
      </header>

      {/* Status pill */}
      <div className="mb-5 flex items-center justify-between rounded-3xl bg-card p-4 border border-border shadow-card">
        <div className="flex items-center gap-3">
          <span className={`flex h-10 w-10 items-center justify-center rounded-2xl ${state?.online ? "grad-primary" : "bg-muted"}`}>
            <Power className="text-primary-foreground" size={18} />
          </span>
          <div>
            <p className="text-sm font-semibold">{state?.command ?? "STOP"}</p>
            <p className="text-[11px] text-muted-foreground">Mode: {state?.mode ?? "manual"} · Speed {state?.speed ?? 50}%</p>
          </div>
        </div>
        <button
          onClick={() => update({ mode: state?.mode === "auto" ? "manual" : "auto" })}
          className="rounded-2xl px-3 py-2 text-xs font-semibold bg-surface-elevated border border-border"
        >
          {state?.mode === "auto" ? "Switch to Manual" : "Enable Auto"}
        </button>
      </div>

      {/* D-Pad */}
      <section className="rounded-3xl bg-card border border-border p-4 shadow-card">
        <div className="grid grid-cols-3 gap-3">
          <div />
          <Btn cmd="FORWARD" icon={ArrowUp} />
          <div />
          <Btn cmd="LEFT" icon={ArrowLeft} />
          <Btn cmd="STOP" icon={Square} variant="stop" />
          <Btn cmd="RIGHT" icon={ArrowRight} />
          <div />
          <Btn cmd="BACKWARD" icon={ArrowDown} />
          <div />
        </div>

        {/* Speed */}
        <div className="mt-5">
          <div className="mb-2 flex items-center justify-between text-xs">
            <span className="flex items-center gap-1.5 text-muted-foreground"><Gauge size={12} /> Speed</span>
            <span className="font-semibold">{state?.speed ?? 50}%</span>
          </div>
          <input
            type="range"
            min={10}
            max={100}
            value={state?.speed ?? 50}
            onChange={(e) => update({ speed: Number(e.target.value) })}
            className="w-full accent-primary"
          />
        </div>
      </section>

      {/* Action toggles */}
      <section className="mt-5 grid grid-cols-1 gap-3">
        <ActionToggle
          label="Irrigation"
          desc={state?.is_watering ? "Pump active — watering crops" : "Pump off"}
          icon={Droplets}
          active={!!state?.is_watering}
          tone="accent"
          onToggle={() => update({ is_watering: !state?.is_watering })}
        />
        <ActionToggle
          label="Ploughing"
          desc={state?.is_ploughing ? "Plough engaged" : "Plough retracted"}
          icon={Tractor}
          active={!!state?.is_ploughing}
          tone="warm"
          onToggle={() => update({ is_ploughing: !state?.is_ploughing })}
        />
        <ActionToggle
          label="Seeding"
          desc={state?.is_seeding ? "Seed dispenser running" : "Seed dispenser off"}
          icon={Sprout}
          active={!!state?.is_seeding}
          tone="primary"
          onToggle={() => update({ is_seeding: !state?.is_seeding })}
        />
      </section>

      {/* Obstacle warning */}
      {(latest?.ultrasonic ?? 999) < 30 && (
        <div className="mt-5 flex items-center gap-3 rounded-3xl border border-destructive/30 bg-destructive/10 p-4">
          <Zap className="text-destructive" />
          <div>
            <p className="text-sm font-semibold text-destructive">Obstacle {latest?.ultrasonic?.toFixed(0)}cm ahead</p>
            <p className="text-[11px] text-muted-foreground">Auto-stop engaged for safety.</p>
          </div>
        </div>
      )}
    </div>
  );
}

function ActionToggle({
  label, desc, icon: Icon, active, tone, onToggle,
}: {
  label: string;
  desc: string;
  icon: typeof Droplets;
  active: boolean;
  tone: "primary" | "accent" | "warm";
  onToggle: () => void;
}) {
  const grad = tone === "accent" ? "grad-water" : tone === "warm" ? "grad-warm" : "grad-primary";
  return (
    <button
      onClick={onToggle}
      className={`flex items-center gap-3 rounded-3xl border p-4 text-left transition-all active:scale-[0.98] ${
        active ? "border-transparent " + grad + " text-primary-foreground glow-primary" : "border-border bg-card"
      }`}
    >
      <span className={`flex h-12 w-12 items-center justify-center rounded-2xl ${active ? "bg-white/20" : grad + " text-primary-foreground"}`}>
        <Icon size={20} />
      </span>
      <div className="flex-1 min-w-0">
        <p className="text-sm font-semibold">{label}</p>
        <p className={`text-[11px] ${active ? "text-primary-foreground/80" : "text-muted-foreground"}`}>{desc}</p>
      </div>
      <span
        className={`relative h-7 w-12 rounded-full transition-colors ${active ? "bg-white/30" : "bg-muted"}`}
      >
        <span className={`absolute top-0.5 h-6 w-6 rounded-full bg-white transition-transform ${active ? "translate-x-5" : "translate-x-0.5"}`} />
      </span>
    </button>
  );
}
