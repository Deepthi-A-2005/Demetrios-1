import { createFileRoute } from "@tanstack/react-router";
import { Bell, Wifi, Smartphone, Info, Github, Cpu, Battery, AlertCircle, Trash2 } from "lucide-react";
import { useAlerts, useRover } from "@/hooks/useAgriData";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/settings")({
  component: SettingsPage,
});

function SettingsPage() {
  const { state } = useRover();
  const { alerts, acknowledge } = useAlerts(20);

  const clearLogs = async () => {
    if (!confirm("Clear all sensor history & logs?")) return;
    await supabase.from("sensor_readings").delete().neq("id", "00000000-0000-0000-0000-000000000000");
    await supabase.from("rover_logs").delete().neq("id", "00000000-0000-0000-0000-000000000000");
  };

  return (
    <div className="px-4 pt-6 safe-top">
      <header className="mb-5">
        <p className="text-xs font-medium uppercase tracking-widest text-muted-foreground">Configuration</p>
        <h1 className="mt-1 text-3xl font-bold tracking-tight">Settings</h1>
      </header>

      {/* Device card */}
      <section className="rounded-3xl bg-card border border-border p-4 shadow-card">
        <div className="flex items-center gap-3">
          <span className="h-12 w-12 rounded-2xl grad-primary flex items-center justify-center text-primary-foreground glow-primary">
            <Cpu size={20} />
          </span>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-semibold">Demetrios · Field Unit 01</p>
            <p className="text-[11px] text-muted-foreground truncate">Arduino Mega + ESP32-CAM</p>
          </div>
          <span className={`rounded-full px-2 py-1 text-[10px] font-bold uppercase ${state?.online ? "bg-primary/15 text-primary" : "bg-muted text-muted-foreground"}`}>
            {state?.online ? "Online" : "Offline"}
          </span>
        </div>
        <div className="mt-4 grid grid-cols-3 gap-2 text-center">
          <Stat icon={Wifi} label="Network" value="WiFi" />
          <Stat icon={Battery} label="Power" value="12V" />
          <Stat icon={Smartphone} label="Mode" value={state?.mode ?? "manual"} />
        </div>
      </section>

      {/* Alerts */}
      <section className="mt-5 rounded-3xl bg-card border border-border p-4 shadow-card">
        <div className="mb-3 flex items-center gap-2">
          <Bell size={16} className="text-primary" />
          <h2 className="text-sm font-semibold">Notifications</h2>
        </div>
        {alerts.length === 0 ? (
          <p className="text-xs text-muted-foreground">No alerts. All clear.</p>
        ) : (
          <ul className="space-y-2">
            {alerts.map((a) => (
              <li key={a.id} className={`flex items-start gap-3 rounded-2xl p-3 ${a.acknowledged ? "bg-surface-elevated/50" : "bg-surface-elevated"}`}>
                <AlertCircle
                  size={16}
                  className={
                    a.level === "critical" ? "text-destructive" :
                    a.level === "warning" ? "text-warning" : "text-info"
                  }
                />
                <div className="flex-1 min-w-0">
                  <p className={`text-sm font-medium ${a.acknowledged ? "line-through text-muted-foreground" : ""}`}>{a.title}</p>
                  {a.message && <p className="text-[11px] text-muted-foreground">{a.message}</p>}
                  <p className="text-[10px] text-muted-foreground mt-0.5">{new Date(a.created_at).toLocaleString()}</p>
                </div>
                {!a.acknowledged && (
                  <button
                    onClick={() => acknowledge(a.id)}
                    className="rounded-full px-2 py-1 text-[10px] font-semibold bg-primary/15 text-primary"
                  >
                    Got it
                  </button>
                )}
              </li>
            ))}
          </ul>
        )}
      </section>

      {/* Maintenance */}
      <section className="mt-5 rounded-3xl bg-card border border-border p-4 shadow-card">
        <h2 className="mb-3 text-sm font-semibold">Maintenance</h2>
        <button
          onClick={clearLogs}
          className="flex w-full items-center justify-between rounded-2xl bg-surface-elevated p-3 text-sm font-medium"
        >
          <span className="flex items-center gap-2"><Trash2 size={14} className="text-destructive" /> Clear sensor history</span>
          <span className="text-xs text-muted-foreground">→</span>
        </button>
      </section>

      {/* About */}
      <section className="mt-5 rounded-3xl bg-card border border-border p-4 shadow-card">
        <div className="mb-3 flex items-center gap-2">
          <Info size={16} className="text-primary" />
          <h2 className="text-sm font-semibold">About</h2>
        </div>
        <p className="text-xs text-muted-foreground leading-relaxed">
          Demetrios combines IoT sensors, computer vision and autonomous navigation to bring precision agriculture to small farms.
          Tap "Add to Home Screen" in your browser menu to install the app.
        </p>
        <a
          href="#"
          onClick={(e) => e.preventDefault()}
          className="mt-3 inline-flex items-center gap-2 text-xs text-primary font-semibold"
        >
          <Github size={14} /> v2.0 · Demetrios Agriculture Rover
        </a>
      </section>
    </div>
  );
}

function Stat({ icon: Icon, label, value }: { icon: typeof Bell; label: string; value: string }) {
  return (
    <div className="rounded-2xl bg-surface-elevated p-3">
      <Icon size={14} className="mx-auto text-muted-foreground" />
      <p className="mt-1 text-[10px] uppercase tracking-wider text-muted-foreground">{label}</p>
      <p className="text-xs font-bold capitalize">{value}</p>
    </div>
  );
}
