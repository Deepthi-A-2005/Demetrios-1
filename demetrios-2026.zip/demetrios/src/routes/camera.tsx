import { createFileRoute } from "@tanstack/react-router";
import { Camera, Leaf, Sparkles, Plus } from "lucide-react";
import { useAnalyses } from "@/hooks/useAgriData";
import { supabase } from "@/integrations/supabase/client";
import { useState } from "react";

export const Route = createFileRoute("/camera")({
  component: CameraPage,
});

const SAMPLE_IMAGES = [
  "https://images.unsplash.com/photo-1530507629858-e3759c1f1d7b?auto=format&fit=crop&w=600&q=70",
  "https://images.unsplash.com/photo-1574943320219-553eb213f72d?auto=format&fit=crop&w=600&q=70",
  "https://images.unsplash.com/photo-1518977676601-b53f82aba655?auto=format&fit=crop&w=600&q=70",
  "https://images.unsplash.com/photo-1592982537447-7440770cbfc9?auto=format&fit=crop&w=600&q=70",
];

const CROPS = ["Tomato", "Wheat", "Rice", "Corn", "Cotton", "Spinach"];
const STATUSES = ["Good", "Warning", "Critical"] as const;
const RECOS: Record<(typeof STATUSES)[number], string[]> = {
  Good: ["Crop healthy. Maintain irrigation.", "Excellent leaf colour. No action needed."],
  Warning: ["Yellowing detected — check nitrogen.", "Mild leaf curl — reduce watering."],
  Critical: ["Possible blight — apply organic fungicide.", "Pest activity detected — inspect rows."],
};

export function CameraPage() {
  const analyses = useAnalyses(30);
  const [busy, setBusy] = useState(false);
  const [filter, setFilter] = useState<"All" | (typeof STATUSES)[number]>("All");

  const capture = async () => {
    setBusy(true);
    if (navigator.vibrate) navigator.vibrate(20);
    const status = STATUSES[Math.floor(Math.random() * STATUSES.length)];
    const reco = RECOS[status][Math.floor(Math.random() * RECOS[status].length)];
    await supabase.from("crop_analyses").insert({
      image_url: SAMPLE_IMAGES[Math.floor(Math.random() * SAMPLE_IMAGES.length)],
      health_status: status,
      crop_type: CROPS[Math.floor(Math.random() * CROPS.length)],
      confidence: 70 + Math.random() * 30,
      recommendation: reco,
      latitude: 12.9716 + (Math.random() - 0.5) * 0.001,
      longitude: 77.5946 + (Math.random() - 0.5) * 0.001,
    });
    setBusy(false);
  };

  const filtered = filter === "All" ? analyses : analyses.filter((a) => a.health_status === filter);

  return (
    <div className="px-4 pt-6 safe-top">
      <header className="mb-4">
        <p className="text-xs font-medium uppercase tracking-widest text-muted-foreground">Crop intelligence</p>
        <h1 className="mt-1 text-3xl font-bold tracking-tight">Captures</h1>
      </header>

      {/* Capture button */}
      <button
        onClick={capture}
        disabled={busy}
        className="mb-4 w-full rounded-3xl grad-primary text-primary-foreground py-4 font-semibold flex items-center justify-center gap-2 glow-primary active:scale-[0.98] transition-transform disabled:opacity-60"
      >
        <Camera size={18} />
        {busy ? "Analysing crop…" : "Capture & Analyse"}
      </button>

      {/* Filters */}
      <div className="mb-4 flex gap-2 overflow-x-auto -mx-4 px-4 pb-1">
        {(["All", ...STATUSES] as const).map((f) => (
          <button
            key={f}
            onClick={() => setFilter(f)}
            className={`shrink-0 rounded-full px-4 py-1.5 text-xs font-semibold border transition-colors ${
              filter === f ? "grad-primary text-primary-foreground border-transparent" : "bg-card border-border text-muted-foreground"
            }`}
          >
            {f}
          </button>
        ))}
      </div>

      {/* Grid */}
      {filtered.length === 0 ? (
        <div className="rounded-3xl border border-dashed border-border p-10 text-center">
          <Leaf className="mx-auto mb-2 text-muted-foreground" />
          <p className="text-sm text-muted-foreground">No captures yet.</p>
          <button onClick={capture} className="mt-3 inline-flex items-center gap-1 text-xs text-primary font-semibold">
            <Plus size={14} /> Take first capture
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-2 gap-3">
          {filtered.map((a) => {
            const tone =
              a.health_status === "Good" ? "bg-primary/15 text-primary" :
              a.health_status === "Warning" ? "bg-warning/15 text-warning" :
              "bg-destructive/15 text-destructive";
            return (
              <div key={a.id} className="rounded-3xl bg-card border border-border overflow-hidden shadow-card">
                {a.image_url ? (
                  <img src={a.image_url} alt={a.crop_type ?? "crop"} className="aspect-square w-full object-cover" loading="lazy" />
                ) : (
                  <div className="aspect-square bg-surface-elevated flex items-center justify-center">
                    <Leaf className="text-muted-foreground" />
                  </div>
                )}
                <div className="p-3">
                  <div className="flex items-center justify-between">
                    <p className="text-sm font-semibold truncate">{a.crop_type ?? "Crop"}</p>
                    <span className={`text-[10px] uppercase tracking-wider font-bold rounded-full px-2 py-0.5 ${tone}`}>
                      {a.health_status}
                    </span>
                  </div>
                  {a.recommendation && (
                    <p className="mt-1 text-[11px] text-muted-foreground line-clamp-2 flex items-start gap-1">
                      <Sparkles size={10} className="mt-0.5 shrink-0 text-primary" /> {a.recommendation}
                    </p>
                  )}
                  <p className="mt-1 text-[10px] text-muted-foreground">
                    {new Date(a.created_at).toLocaleString()}
                  </p>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
