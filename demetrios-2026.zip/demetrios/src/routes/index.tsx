import { createFileRoute } from "@tanstack/react-router";
import { Link } from "@tanstack/react-router";
import {
  Droplets, Thermometer, Wind, Leaf, Battery, Activity, AlertTriangle,
  Camera, ChevronRight, Sparkles,
} from "lucide-react";
import {
  Area, AreaChart, ResponsiveContainer, XAxis, YAxis, Tooltip,
} from "recharts";
import { useSensorHistory, useRover, useAlerts, useAnalyses } from "@/hooks/useAgriData";
import { SensorTile } from "@/components/SensorTile";

export const Route = createFileRoute("/")({
  component: Dashboard,
});

function Dashboard() {
  const { data, latest, loading } = useSensorHistory(40);
  const { state: rover } = useRover();
  const { alerts } = useAlerts(5);
  const analyses = useAnalyses(3);

  const greeting = (() => {
    const h = new Date().getHours();
    if (h < 12) return "Good morning";
    if (h < 18) return "Good afternoon";
    return "Good evening";
  })();

  const moistureStatus =
    !latest?.moisture
      ? "—"
      : latest.moisture < 30
        ? "Soil is dry — watering recommended"
        : latest.moisture > 70
          ? "Soil well saturated"
          : "Soil moisture is healthy";

  return (
    <div className="px-4 pt-6 safe-top">
      {/* Greeting */}
      <header className="mb-5">
        <p className="text-xs font-medium uppercase tracking-widest text-muted-foreground">
          {greeting}
        </p>
        <h1 className="mt-1 text-3xl font-bold tracking-tight text-balance">
          Demetrios <span className="text-primary">live</span>
        </h1>
        <div className="mt-3 flex items-center gap-2">
          <span
            className={`inline-flex h-2 w-2 rounded-full ${
              rover?.online ? "bg-primary animate-pulse-soft" : "bg-muted-foreground"
            }`}
          />
          <span className="text-xs text-muted-foreground">
            {loading
              ? "Connecting to Demetrios…"
              : rover?.online
                ? `Demetrios online · ${rover.command} · battery ${latest?.battery?.toFixed(0) ?? "—"}%`
                : "Demetrios offline"}
          </span>
        </div>
      </header>

      {/* Sensor grid */}
      <section className="grid grid-cols-2 gap-3">
        <SensorTile label="Soil Moisture" value={latest?.moisture} unit="%" icon={Droplets} tone="accent" hint={moistureStatus.split(" — ")[1] ?? undefined} />
        <SensorTile label="Temperature" value={latest?.temperature} unit="°C" icon={Thermometer} tone="warm" />
        <SensorTile label="Humidity" value={latest?.humidity} unit="%" icon={Wind} tone="primary" />
        <SensorTile label="Soil pH" value={latest?.ph} unit="pH" icon={Leaf} tone="primary" />
      </section>

      {/* Live chart */}
      <section className="mt-5 rounded-3xl bg-card p-4 shadow-card border border-border">
        <div className="mb-3 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="flex h-8 w-8 items-center justify-center rounded-xl grad-primary text-primary-foreground">
              <Activity size={16} />
            </span>
            <div>
              <h2 className="text-sm font-semibold">Field Conditions</h2>
              <p className="text-[11px] text-muted-foreground">Last {data.length} readings · live</p>
            </div>
          </div>
        </div>
        <div className="h-44">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={data} margin={{ top: 5, right: 0, left: -20, bottom: 0 }}>
              <defs>
                <linearGradient id="gMoist" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="oklch(0.78 0.16 220)" stopOpacity={0.5} />
                  <stop offset="100%" stopColor="oklch(0.78 0.16 220)" stopOpacity={0} />
                </linearGradient>
                <linearGradient id="gTemp" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="oklch(0.82 0.17 75)" stopOpacity={0.45} />
                  <stop offset="100%" stopColor="oklch(0.82 0.17 75)" stopOpacity={0} />
                </linearGradient>
              </defs>
              <XAxis dataKey="created_at" hide />
              <YAxis stroke="oklch(1 0 0 / 0.3)" fontSize={10} width={28} />
              <Tooltip
                contentStyle={{
                  background: "oklch(0.21 0.025 150)",
                  border: "1px solid oklch(1 0 0 / 0.1)",
                  borderRadius: 12,
                  fontSize: 12,
                }}
                labelFormatter={(v) => new Date(v).toLocaleTimeString()}
              />
              <Area type="monotone" dataKey="moisture" stroke="oklch(0.78 0.16 220)" strokeWidth={2} fill="url(#gMoist)" />
              <Area type="monotone" dataKey="temperature" stroke="oklch(0.82 0.17 75)" strokeWidth={2} fill="url(#gTemp)" />
            </AreaChart>
          </ResponsiveContainer>
        </div>
        <div className="mt-2 flex gap-4 text-[11px] text-muted-foreground">
          <span className="flex items-center gap-1.5"><span className="h-2 w-2 rounded-full bg-accent" />Moisture %</span>
          <span className="flex items-center gap-1.5"><span className="h-2 w-2 rounded-full bg-warning" />Temp °C</span>
        </div>
      </section>

      {/* Recommendation */}
      <section className="mt-5 rounded-3xl border border-primary/20 bg-card p-4 shadow-card">
        <div className="flex items-start gap-3">
          <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl grad-primary text-primary-foreground">
            <Sparkles size={16} />
          </span>
          <div>
            <h3 className="text-sm font-semibold">Crop Recommendation</h3>
            <p className="mt-1 text-sm text-muted-foreground">{moistureStatus}. {latest?.ph && latest.ph < 6 ? "Soil is acidic — consider liming." : latest?.ph && latest.ph > 7.5 ? "Soil is alkaline — sulfur amendment helps." : "pH range is ideal for most crops."}</p>
          </div>
        </div>
      </section>

      {/* Battery + status row */}
      <section className="mt-5 grid grid-cols-2 gap-3">
        <div className="rounded-3xl bg-card p-4 shadow-card border border-border">
          <div className="flex items-center gap-2 text-muted-foreground">
            <Battery size={14} />
            <span className="text-[11px] uppercase tracking-wider font-semibold">Battery</span>
          </div>
          <p className="mt-2 text-2xl font-bold">{latest?.battery?.toFixed(0) ?? "—"}<span className="text-base text-muted-foreground">%</span></p>
          <div className="mt-2 h-1.5 w-full overflow-hidden rounded-full bg-muted">
            <div className="h-full grad-primary" style={{ width: `${latest?.battery ?? 0}%` }} />
          </div>
        </div>
        <div className="rounded-3xl bg-card p-4 shadow-card border border-border">
          <div className="flex items-center gap-2 text-muted-foreground">
            <AlertTriangle size={14} />
            <span className="text-[11px] uppercase tracking-wider font-semibold">Obstacle</span>
          </div>
          <p className="mt-2 text-2xl font-bold">{latest?.ultrasonic?.toFixed(0) ?? "—"}<span className="text-base text-muted-foreground"> cm</span></p>
          <p className="mt-1 text-[11px] text-muted-foreground">{(latest?.ultrasonic ?? 999) < 30 ? "Object close ahead" : "Path clear"}</p>
        </div>
      </section>

      {/* Alerts */}
      {alerts.length > 0 && (
        <section className="mt-5 rounded-3xl bg-card p-4 shadow-card border border-border">
          <h3 className="mb-3 text-sm font-semibold">Recent alerts</h3>
          <ul className="space-y-2">
            {alerts.slice(0, 3).map((a) => (
              <li key={a.id} className="flex items-start gap-3 rounded-2xl bg-surface-elevated p-3">
                <span
                  className={`mt-0.5 h-2 w-2 shrink-0 rounded-full ${
                    a.level === "critical" ? "bg-destructive" : a.level === "warning" ? "bg-warning" : "bg-info"
                  }`}
                />
                <div className="flex-1 min-w-0">
                  <p className="truncate text-sm font-medium">{a.title}</p>
                  {a.message && <p className="truncate text-[11px] text-muted-foreground">{a.message}</p>}
                </div>
              </li>
            ))}
          </ul>
        </section>
      )}

      {/* Latest captures preview */}
      <section className="mt-5">
        <div className="mb-3 flex items-center justify-between">
          <h3 className="text-sm font-semibold">Latest captures</h3>
          <Link to="/camera" className="flex items-center gap-1 text-xs text-primary">
            View all <ChevronRight size={14} />
          </Link>
        </div>
        {analyses.length === 0 ? (
          <div className="rounded-3xl border border-dashed border-border p-6 text-center">
            <Camera className="mx-auto mb-2 text-muted-foreground" size={20} />
            <p className="text-xs text-muted-foreground">No crop captures yet. Take one from the Crops tab.</p>
          </div>
        ) : (
          <div className="flex gap-3 overflow-x-auto pb-1 -mx-4 px-4 snap-x">
            {analyses.map((a) => (
              <div key={a.id} className="snap-start w-40 shrink-0 rounded-2xl overflow-hidden bg-card border border-border">
                {a.image_url ? (
                  <img src={a.image_url} alt={a.crop_type ?? "crop"} className="aspect-square w-full object-cover" loading="lazy" />
                ) : (
                  <div className="aspect-square w-full flex items-center justify-center bg-surface-elevated">
                    <Leaf className="text-muted-foreground" />
                  </div>
                )}
                <div className="p-2">
                  <p className="text-xs font-medium truncate">{a.crop_type ?? "Unknown crop"}</p>
                  <p className={`text-[10px] uppercase tracking-wider font-semibold ${a.health_status === "Good" ? "text-primary" : a.health_status === "Warning" ? "text-warning" : "text-destructive"}`}>
                    {a.health_status}
                  </p>
                </div>
              </div>
            ))}
          </div>
        )}
      </section>
    </div>
  );
}
