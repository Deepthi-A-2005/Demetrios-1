import { createFileRoute } from "@tanstack/react-router";
import { MapPin, Navigation, Compass } from "lucide-react";
import { useSensorHistory, useRover } from "@/hooks/useAgriData";
import { useMemo } from "react";

export const Route = createFileRoute("/map")({
  component: MapPage,
});

function MapPage() {
  const { data, latest } = useSensorHistory(60);
  const { state } = useRover();

  // Project lat/lng path into svg coordinates
  const path = useMemo(() => {
    const points = data
      .filter((d) => d.latitude != null && d.longitude != null)
      .map((d) => ({ x: d.longitude as number, y: d.latitude as number }));
    if (points.length < 2) return { d: "", points: [] as { cx: number; cy: number }[] };
    const xs = points.map((p) => p.x);
    const ys = points.map((p) => p.y);
    const minX = Math.min(...xs), maxX = Math.max(...xs);
    const minY = Math.min(...ys), maxY = Math.max(...ys);
    const rangeX = Math.max(maxX - minX, 0.0005);
    const rangeY = Math.max(maxY - minY, 0.0005);
    const W = 320, H = 320, P = 30;
    const projected = points.map((p) => ({
      cx: P + ((p.x - minX) / rangeX) * (W - 2 * P),
      cy: H - (P + ((p.y - minY) / rangeY) * (H - 2 * P)),
    }));
    const d = projected.reduce((acc, p, i) => acc + (i === 0 ? `M${p.cx},${p.cy}` : ` L${p.cx},${p.cy}`), "");
    return { d, points: projected };
  }, [data]);

  const last = path.points[path.points.length - 1];

  return (
    <div className="px-4 pt-6 safe-top">
      <header className="mb-4">
        <p className="text-xs font-medium uppercase tracking-widest text-muted-foreground">Field positioning</p>
        <h1 className="mt-1 text-3xl font-bold tracking-tight">Live Map</h1>
      </header>

      {/* Map card */}
      <section className="relative rounded-3xl overflow-hidden bg-card border border-border shadow-card">
        <div className="relative aspect-square w-full bg-[radial-gradient(ellipse_at_center,oklch(0.25_0.04_150)_0%,oklch(0.16_0.02_150)_70%)]">
          {/* Grid overlay */}
          <svg viewBox="0 0 320 320" className="absolute inset-0 h-full w-full">
            <defs>
              <pattern id="grid" width="32" height="32" patternUnits="userSpaceOnUse">
                <path d="M32 0 L0 0 0 32" fill="none" stroke="oklch(1 0 0 / 0.06)" strokeWidth="1" />
              </pattern>
            </defs>
            <rect width="320" height="320" fill="url(#grid)" />
            {/* Path */}
            {path.d && (
              <path d={path.d} fill="none" stroke="oklch(0.78 0.19 145)" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
            )}
            {/* Waypoints */}
            {path.points.map((p, i) => (
              <circle key={i} cx={p.cx} cy={p.cy} r={i === path.points.length - 1 ? 0 : 2} fill="oklch(0.78 0.19 145 / 0.6)" />
            ))}
            {/* Rover marker */}
            {last && (
              <g>
                <circle cx={last.cx} cy={last.cy} r={14} fill="oklch(0.78 0.19 145 / 0.2)" className="animate-pulse-soft" />
                <circle cx={last.cx} cy={last.cy} r={7} fill="oklch(0.78 0.19 145)" stroke="white" strokeWidth="2" />
              </g>
            )}
          </svg>

          {/* Compass */}
          <div className="absolute top-3 right-3 glass rounded-2xl p-2 border border-border">
            <Compass size={20} className="text-primary" />
          </div>
        </div>

        {/* Coords readout */}
        <div className="grid grid-cols-2 gap-px bg-border">
          <div className="bg-card p-3">
            <p className="text-[10px] uppercase tracking-wider text-muted-foreground">Latitude</p>
            <p className="font-mono text-sm font-semibold">{latest?.latitude?.toFixed(6) ?? "—"}</p>
          </div>
          <div className="bg-card p-3">
            <p className="text-[10px] uppercase tracking-wider text-muted-foreground">Longitude</p>
            <p className="font-mono text-sm font-semibold">{latest?.longitude?.toFixed(6) ?? "—"}</p>
          </div>
        </div>
      </section>

      {/* Trip stats */}
      <section className="mt-4 grid grid-cols-3 gap-3">
        <div className="rounded-2xl bg-card border border-border p-3">
          <p className="text-[10px] uppercase tracking-wider text-muted-foreground flex items-center gap-1"><Navigation size={10} />Heading</p>
          <p className="mt-1 font-bold">{state?.command ?? "STOP"}</p>
        </div>
        <div className="rounded-2xl bg-card border border-border p-3">
          <p className="text-[10px] uppercase tracking-wider text-muted-foreground flex items-center gap-1"><MapPin size={10} />Waypoints</p>
          <p className="mt-1 font-bold">{path.points.length}</p>
        </div>
        <div className="rounded-2xl bg-card border border-border p-3">
          <p className="text-[10px] uppercase tracking-wider text-muted-foreground">Speed</p>
          <p className="mt-1 font-bold">{state?.speed ?? 0}%</p>
        </div>
      </section>
    </div>
  );
}
