// Lightweight simulator that pretends to be the rover/IoT hardware.
// Periodically inserts a new sensor reading so charts stay alive.
// In production you'd POST these from Arduino / ESP32 / a backend.
import { supabase } from "@/integrations/supabase/client";

let started = false;
let timer: number | undefined;
let lat = 12.9716;
let lng = 77.5946;
let moisture = 48;
let temp = 26;
let humidity = 62;
let ph = 6.7;
let battery = 92;

function jitter(v: number, amount = 1) {
  return v + (Math.random() - 0.5) * amount;
}
function clamp(v: number, lo: number, hi: number) {
  return Math.max(lo, Math.min(hi, v));
}

export function startAgriSimulator() {
  if (started || typeof window === "undefined") return;
  started = true;

  const tick = async () => {
    // pull current rover state to react to commands
    const { data: rover } = await supabase
      .from("rover_state")
      .select("*")
      .eq("id", "main")
      .single();

    // movement updates lat/lng based on command
    const step = 0.00006;
    if (rover?.command === "FORWARD") lat += step;
    else if (rover?.command === "BACKWARD") lat -= step;
    else if (rover?.command === "LEFT") lng -= step;
    else if (rover?.command === "RIGHT") lng += step;

    // watering boosts moisture, sun dries it
    if (rover?.is_watering) moisture = clamp(moisture + 2, 0, 100);
    else moisture = clamp(jitter(moisture, 0.6) - 0.2, 10, 90);

    temp = clamp(jitter(temp, 0.3), 18, 38);
    humidity = clamp(jitter(humidity, 0.6), 30, 90);
    ph = clamp(jitter(ph, 0.04), 5.5, 8);
    battery = clamp(battery - 0.02 - (rover?.is_watering ? 0.05 : 0), 0, 100);

    const ultrasonic = clamp(jitter(150, 80), 5, 250);

    await supabase.from("sensor_readings").insert({
      moisture,
      temperature: temp,
      humidity,
      ph,
      ultrasonic,
      latitude: lat,
      longitude: lng,
      battery,
    });

    // alert on low battery / dry soil / obstacle
    if (moisture < 25 && Math.random() < 0.05) {
      await supabase.from("alerts").insert({
        level: "warning",
        title: "Low soil moisture",
        message: `Moisture at ${moisture.toFixed(0)}% — consider watering.`,
      });
    }
    if (ultrasonic < 15 && Math.random() < 0.1) {
      await supabase.from("alerts").insert({
        level: "critical",
        title: "Obstacle detected",
        message: `Object ${ultrasonic.toFixed(0)} cm ahead. Rover stopped.`,
      });
      await supabase.from("rover_state").update({ command: "STOP" }).eq("id", "main");
    }
  };

  // run quickly the first time, then every 3s
  void tick();
  timer = window.setInterval(tick, 3000) as unknown as number;
}

export function stopAgriSimulator() {
  if (timer) window.clearInterval(timer);
  started = false;
}
