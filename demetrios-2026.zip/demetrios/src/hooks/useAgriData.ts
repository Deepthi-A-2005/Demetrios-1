import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";

export type Sensor = {
  id: string;
  moisture: number | null;
  temperature: number | null;
  humidity: number | null;
  ph: number | null;
  ultrasonic: number | null;
  latitude: number | null;
  longitude: number | null;
  battery: number | null;
  created_at: string;
};

export type RoverState = {
  id: string;
  command: string;
  is_watering: boolean;
  is_ploughing: boolean;
  is_seeding: boolean;
  mode: string;
  speed: number;
  online: boolean;
  last_seen: string;
  updated_at: string;
};

export type CropAnalysis = {
  id: string;
  image_url: string | null;
  health_status: string;
  crop_type: string | null;
  disease: string | null;
  confidence: number | null;
  recommendation: string | null;
  latitude: number | null;
  longitude: number | null;
  created_at: string;
};

export type Alert = {
  id: string;
  level: "info" | "warning" | "critical";
  title: string;
  message: string | null;
  acknowledged: boolean;
  created_at: string;
};

export function useSensorHistory(limit = 40) {
  const [data, setData] = useState<Sensor[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let active = true;
    const load = async () => {
      const { data: rows } = await supabase
        .from("sensor_readings")
        .select("*")
        .order("created_at", { ascending: false })
        .limit(limit);
      if (active && rows) {
        setData([...rows].reverse() as Sensor[]);
        setLoading(false);
      }
    };
    load();
    const ch = supabase
      .channel("sensor_readings_rt")
      .on(
        "postgres_changes",
        { event: "INSERT", schema: "public", table: "sensor_readings" },
        (payload) => {
          setData((prev) => {
            const next = [...prev, payload.new as Sensor];
            return next.slice(-limit);
          });
        },
      )
      .subscribe();
    return () => {
      active = false;
      supabase.removeChannel(ch);
    };
  }, [limit]);

  const latest = data[data.length - 1];
  return { data, latest, loading };
}

export function useRover() {
  const [state, setState] = useState<RoverState | null>(null);

  useEffect(() => {
    let active = true;
    const load = async () => {
      const { data } = await supabase.from("rover_state").select("*").eq("id", "main").single();
      if (active && data) setState(data as RoverState);
    };
    load();
    const ch = supabase
      .channel("rover_state_rt")
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "rover_state" },
        (payload) => setState(payload.new as RoverState),
      )
      .subscribe();
    return () => {
      active = false;
      supabase.removeChannel(ch);
    };
  }, []);

  const update = async (patch: Partial<RoverState>) => {
    setState((s) => (s ? { ...s, ...patch } : s));
    await supabase
      .from("rover_state")
      .update({ ...patch, updated_at: new Date().toISOString(), last_seen: new Date().toISOString() })
      .eq("id", "main");
    await supabase.from("rover_logs").insert({
      event_type: patch.command ? "move" : patch.is_watering !== undefined ? "water" : "control",
      details: patch,
    });
  };

  return { state, update };
}

export function useAnalyses(limit = 20) {
  const [data, setData] = useState<CropAnalysis[]>([]);
  useEffect(() => {
    let active = true;
    const load = async () => {
      const { data: rows } = await supabase
        .from("crop_analyses")
        .select("*")
        .order("created_at", { ascending: false })
        .limit(limit);
      if (active && rows) setData(rows as CropAnalysis[]);
    };
    load();
    const ch = supabase
      .channel("crop_analyses_rt")
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "crop_analyses" },
        load,
      )
      .subscribe();
    return () => {
      active = false;
      supabase.removeChannel(ch);
    };
  }, [limit]);
  return data;
}

export function useAlerts(limit = 20) {
  const [data, setData] = useState<Alert[]>([]);
  useEffect(() => {
    let active = true;
    const load = async () => {
      const { data: rows } = await supabase
        .from("alerts")
        .select("*")
        .order("created_at", { ascending: false })
        .limit(limit);
      if (active && rows) setData(rows as Alert[]);
    };
    load();
    const ch = supabase
      .channel("alerts_rt")
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "alerts" },
        load,
      )
      .subscribe();
    return () => {
      active = false;
      supabase.removeChannel(ch);
    };
  }, [limit]);
  const acknowledge = async (id: string) => {
    await supabase.from("alerts").update({ acknowledged: true }).eq("id", id);
  };
  return { alerts: data, acknowledge };
}
