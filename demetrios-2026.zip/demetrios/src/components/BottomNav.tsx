import { Link, useLocation } from "@tanstack/react-router";
import { LayoutDashboard, Gamepad2, Camera, MapPin, Settings } from "lucide-react";

const items = [
  { to: "/", icon: LayoutDashboard, label: "Home" },
  { to: "/control", icon: Gamepad2, label: "Control" },
  { to: "/camera", icon: Camera, label: "Crops" },
  { to: "/map", icon: MapPin, label: "Map" },
  { to: "/settings", icon: Settings, label: "Settings" },
] as const;

export function BottomNav() {
  const { pathname } = useLocation();
  return (
    <nav className="fixed bottom-0 inset-x-0 z-50 safe-bottom px-3 pt-2">
      <div className="glass mx-auto max-w-md rounded-3xl border border-border shadow-card">
        <ul className="grid grid-cols-5 px-2 py-1.5">
          {items.map(({ to, icon: Icon, label }) => {
            const active = to === "/" ? pathname === "/" : pathname.startsWith(to);
            return (
              <li key={to} className="flex">
                <Link
                  to={to}
                  className="group relative mx-auto flex flex-1 flex-col items-center justify-center gap-1 rounded-2xl px-2 py-2 text-[11px] font-medium transition-colors"
                >
                  <span
                    className={`flex h-9 w-9 items-center justify-center rounded-xl transition-all ${
                      active
                        ? "grad-primary text-primary-foreground glow-primary"
                        : "text-muted-foreground group-hover:text-foreground"
                    }`}
                  >
                    <Icon size={18} strokeWidth={2.4} />
                  </span>
                  <span className={active ? "text-foreground" : "text-muted-foreground"}>
                    {label}
                  </span>
                </Link>
              </li>
            );
          })}
        </ul>
      </div>
    </nav>
  );
}
