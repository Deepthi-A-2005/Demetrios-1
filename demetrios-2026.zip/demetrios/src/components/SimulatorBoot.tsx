import { useEffect } from "react";
import { startAgriSimulator } from "@/lib/agriSimulator";

export function SimulatorBoot() {
  useEffect(() => {
    startAgriSimulator();
  }, []);
  return null;
}
