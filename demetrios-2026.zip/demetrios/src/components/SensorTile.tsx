import { type LucideIcon } from "lucide-react";

type Tone = "primary" | "accent" | "warm" | "danger";

const toneStyles: Record<Tone, { bg: string; ring: string; text: string }> = {
  primary: { bg: "grad-primary", ring: "ring-primary/30", text: "text-primary" },
  accent: { bg: "grad-water", ring: "ring-accent/30", text: "text-accent" },
  warm: { bg: "grad-warm", ring: "ring-warning/30", text: "text-warning" },
  danger: { bg: "bg-destructive", ring: "ring-destructive/30", text: "text-destructive" },
};

export function SensorTile({
  label,
  value,
  unit,
  icon: Icon,
  tone = "primary",
  hint,
}: {
  label: string;
  value: number | string | null | undefined;
  unit?: string;
  icon: LucideIcon;
  tone?: Tone;
  hint?: string;
}) {
  const t = toneStyles[tone];
  const display =
    value === null || value === undefined
      ? "—"
      : typeof value === "number"
        ? value.toFixed(value < 10 ? 1 : 0)
        : value;

  return (
    <div className="relative overflow-hidden rounded-3xl bg-card p-4 shadow-card border border-border">
      <div className="flex items-start justify-between">
        <div>
          <p className="text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">
            {label}
          </p>
          <p className="mt-2 text-3xl font-bold tracking-tight">
            {display}
            {unit && <span className="ml-1 text-base font-medium text-muted-foreground">{unit}</span>}
          </p>
          {hint && <p className="mt-1 text-[11px] text-muted-foreground">{hint}</p>}
        </div>
        <div className={`h-10 w-10 rounded-2xl ${t.bg} flex items-center justify-center text-primary-foreground shadow-md`}>
          <Icon size={18} />
        </div>
      </div>
      <div className={`pointer-events-none absolute -bottom-8 -right-8 h-24 w-24 rounded-full ${t.bg} opacity-20 blur-2xl`} />
    </div>
  );
}
