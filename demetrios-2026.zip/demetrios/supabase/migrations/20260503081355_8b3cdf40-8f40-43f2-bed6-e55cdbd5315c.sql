
-- Sensor readings (time series)
CREATE TABLE public.sensor_readings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  moisture NUMERIC,
  temperature NUMERIC,
  humidity NUMERIC,
  ph NUMERIC,
  ultrasonic NUMERIC,
  latitude NUMERIC,
  longitude NUMERIC,
  battery NUMERIC,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_sensor_readings_created_at ON public.sensor_readings (created_at DESC);

-- Rover state (single row keyed by id='main')
CREATE TABLE public.rover_state (
  id TEXT PRIMARY KEY DEFAULT 'main',
  command TEXT NOT NULL DEFAULT 'STOP',
  is_watering BOOLEAN NOT NULL DEFAULT false,
  is_ploughing BOOLEAN NOT NULL DEFAULT false,
  is_seeding BOOLEAN NOT NULL DEFAULT false,
  mode TEXT NOT NULL DEFAULT 'manual', -- manual | auto
  speed INT NOT NULL DEFAULT 50,
  online BOOLEAN NOT NULL DEFAULT true,
  last_seen TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
INSERT INTO public.rover_state (id) VALUES ('main');

-- Crop analyses
CREATE TABLE public.crop_analyses (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  image_url TEXT,
  health_status TEXT NOT NULL DEFAULT 'Unknown', -- Good | Warning | Critical
  crop_type TEXT,
  disease TEXT,
  confidence NUMERIC,
  recommendation TEXT,
  latitude NUMERIC,
  longitude NUMERIC,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_crop_analyses_created_at ON public.crop_analyses (created_at DESC);

-- Alerts
CREATE TABLE public.alerts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  level TEXT NOT NULL DEFAULT 'info', -- info | warning | critical
  title TEXT NOT NULL,
  message TEXT,
  acknowledged BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_alerts_created_at ON public.alerts (created_at DESC);

-- Activity logs
CREATE TABLE public.rover_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  event_type TEXT NOT NULL, -- move | water | plough | seed | obstacle | analysis
  details JSONB,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_rover_logs_created_at ON public.rover_logs (created_at DESC);

-- RLS
ALTER TABLE public.sensor_readings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.rover_state ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.crop_analyses ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.alerts ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.rover_logs ENABLE ROW LEVEL SECURITY;

-- Public read (demo dashboard)
CREATE POLICY "public read sensor_readings" ON public.sensor_readings FOR SELECT USING (true);
CREATE POLICY "public read rover_state" ON public.rover_state FOR SELECT USING (true);
CREATE POLICY "public read crop_analyses" ON public.crop_analyses FOR SELECT USING (true);
CREATE POLICY "public read alerts" ON public.alerts FOR SELECT USING (true);
CREATE POLICY "public read rover_logs" ON public.rover_logs FOR SELECT USING (true);

-- Public write (demo: anyone can post sensor data / control rover; tighten later with auth/api key)
CREATE POLICY "public insert sensor_readings" ON public.sensor_readings FOR INSERT WITH CHECK (true);
CREATE POLICY "public update rover_state" ON public.rover_state FOR UPDATE USING (true) WITH CHECK (true);
CREATE POLICY "public insert crop_analyses" ON public.crop_analyses FOR INSERT WITH CHECK (true);
CREATE POLICY "public update crop_analyses" ON public.crop_analyses FOR UPDATE USING (true) WITH CHECK (true);
CREATE POLICY "public insert alerts" ON public.alerts FOR INSERT WITH CHECK (true);
CREATE POLICY "public update alerts" ON public.alerts FOR UPDATE USING (true) WITH CHECK (true);
CREATE POLICY "public insert rover_logs" ON public.rover_logs FOR INSERT WITH CHECK (true);

-- Realtime
ALTER PUBLICATION supabase_realtime ADD TABLE public.sensor_readings;
ALTER PUBLICATION supabase_realtime ADD TABLE public.rover_state;
ALTER PUBLICATION supabase_realtime ADD TABLE public.crop_analyses;
ALTER PUBLICATION supabase_realtime ADD TABLE public.alerts;

-- Seed a starting reading so charts aren't empty
INSERT INTO public.sensor_readings (moisture, temperature, humidity, ph, ultrasonic, latitude, longitude, battery)
SELECT 40 + random()*20, 22 + random()*8, 55 + random()*15, 6.2 + random()*1.2, 80 + random()*60, 12.9716, 77.5946, 80 + random()*15
FROM generate_series(1, 30);
